
Rotary-Encoders.pretty
======================

LAYOUT FILES: KiCad footprints for various rotary encoders.

